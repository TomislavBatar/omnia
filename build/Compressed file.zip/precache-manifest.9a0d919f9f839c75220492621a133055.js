self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2b815b5b4de630cf04bebc621855be09",
    "url": "/sezona/index.html"
  },
  {
    "revision": "0fc7411b273bce6e1557",
    "url": "/sezona/static/css/2.c6231af7.chunk.css"
  },
  {
    "revision": "d91e966ed25562d88546",
    "url": "/sezona/static/css/main.c5985368.chunk.css"
  },
  {
    "revision": "0fc7411b273bce6e1557",
    "url": "/sezona/static/js/2.c65a067d.chunk.js"
  },
  {
    "revision": "d91e966ed25562d88546",
    "url": "/sezona/static/js/main.acf0bf10.chunk.js"
  },
  {
    "revision": "d15807dd1474aa8e12b4",
    "url": "/sezona/static/js/runtime~main.60e9b267.js"
  },
  {
    "revision": "c327c6e83da905fa2fa00b554f8d2b3b",
    "url": "/sezona/static/media/sezona-logo.c327c6e8.png"
  }
]);