self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "75480f98a36f98f323a9bf42e42c3786",
    "url": "/index.html"
  },
  {
    "revision": "f4c390bec054bc9a4c06",
    "url": "/static/css/main.f432a778.chunk.css"
  },
  {
    "revision": "96acdd8483c9d9d67075",
    "url": "/static/js/2.792422bb.chunk.js"
  },
  {
    "revision": "f4c390bec054bc9a4c06",
    "url": "/static/js/main.26672fe8.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "f0e23d88eac42ac18c71c5d09695de80",
    "url": "/static/media/donji.f0e23d88.svg"
  },
  {
    "revision": "654d0683ae9d351a0cc7fdcd8e963712",
    "url": "/static/media/fb.654d0683.svg"
  },
  {
    "revision": "86ba8819f885e20e789b4b3a3637cb87",
    "url": "/static/media/gore.86ba8819.svg"
  },
  {
    "revision": "7e0244dcce6d1238a6cbdcae40bdfe87",
    "url": "/static/media/ig.7e0244dc.svg"
  },
  {
    "revision": "b4e906b4e7ae1493f1522c74e0656cbf",
    "url": "/static/media/li.b4e906b4.svg"
  },
  {
    "revision": "1d1ccd0f388c0de7278e43394457fd5e",
    "url": "/static/media/logo-omnia-2.1d1ccd0f.svg"
  },
  {
    "revision": "03c7f7a63a6ece948670eaf40cfdbd06",
    "url": "/static/media/omnia logo filled.03c7f7a6.svg"
  }
]);